

from blenderproc.python.constructor.RandomRoomConstructor import construct_random_room
