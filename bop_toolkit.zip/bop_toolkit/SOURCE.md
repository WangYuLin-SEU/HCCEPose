# Bundled BOP toolkit

Source: the complete `bop_toolkit.zip` published in [HCCEPose revision f75cc4d5db2fc298fc7b853f8c75273757872382](https://github.com/WangYuLin-SEU/HCCEPose/blob/f75cc4d5db2fc298fc7b853f8c75273757872382/bop_toolkit.zip).

The runtime library, evaluation, annotation and rendering scripts remain included. Local path setup uses this project instead of machine-specific directories; `BOP_PATH` overrides the dataset directory. Original toolkit and font notices remain included. See `README.md` for toolkit usage.
