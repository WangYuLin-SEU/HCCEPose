# Author: Tomas Hodan (hodantom@cmp.felk.cvut.cz)
# Center for Machine Perception, Czech Technical University in Prague

"""Configuration of the BOP Toolkit."""

import os

# Defaults are project-relative; BOP_PATH overrides the dataset directory.
# 默认路径相对于项目；BOP_PATH 可覆盖数据目录。
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


######## Basic ########

# Folder with the BOP datasets.
if 'BOP_PATH' in os.environ:
  datasets_path = os.environ['BOP_PATH']
else:
  datasets_path = os.path.join(project_root, 'data')

# Folder with pose results to be evaluated.
results_path = os.path.join(project_root, 'outputs', 'results')

# Folder for the calculated pose errors and performance scores.
eval_path = os.path.join(project_root, 'outputs', 'evaluation')

######## Extended ########

# Folder for outputs (e.g. visualizations).
output_path = r'/path/to/output/folder'

# For offscreen C++ rendering: Path to the build folder of bop_renderer (github.com/thodan/bop_renderer).
bop_renderer_path = r'/path/to/bop_renderer/build'

# Executable of the MeshLab server.
meshlab_server_path = r'/path/to/meshlabserver.exe'
